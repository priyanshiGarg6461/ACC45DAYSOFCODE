#include<iostream>
using namespace std;
int main()
{
    int i, j ,n,temp, k,a[100] ,min ;
    cout<<"Enter the size of element :"<<endl;
    cin>>n;
    cout<<"Enter the elements of array :"<<endl;
    for(i=0;i<n;i++)
    cin>>a[i];
    for(i =0 ; i<n-1 ; i++)
    {
        min =i;
        for( j=(i+1) ; j<n; j++)
        {
            if(a[min]>a[j])
            {
                min = j;
                
            }
        }

        {
            temp = a[min];
            a[min] = a[i] ;
            a[i] = temp ;
        }
    }
    cout<<"sorted array n "<<endl;
    for (k = 0; k < n; k++)
    cout<<a[k]<<endl;
    return 0;
}